<?php
	session_start();

	$_SESSION['validUser'] = true;	

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>

	<p><a href="testValidUser.php">Delete Page</a></p>


</body>
</html>